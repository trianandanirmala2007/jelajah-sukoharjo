JELAJAH SUKOHARJO - VERSI PERBAIKAN

CARA MEMAKAI:
1. Ekstrak file ZIP.
2. Buka folder hasil ekstrak di Visual Studio Code.
3. Pastikan index.html, style.css, dan script.js berada dalam satu folder.
4. Klik dua kali index.html atau jalankan dengan ekstensi Live Server.
5. Pastikan laptop terhubung ke internet karena foto dan Google Fonts diambil dari sumber online.

PERBAIKAN:
- Foto hero diganti menjadi Patung Jamu Kabupaten Sukoharjo.
- Foto kartu produk diarahkan ke dokumentasi yang sesuai dengan produk/daerah.
- Layout kartu dibuat responsif dan tidak menyisakan kartu kosong.
- Deskripsi detail dibuka melalui tombol "Lihat informasi".
- Catatan panjang di bagian bawah yang sebelumnya mengganggu sudah dihilangkan.
- Pencarian dan filter kategori tetap tersedia.

CATATAN FOTO:
Foto hero Patung Jamu bersumber dari Wikimedia Commons, berkas Patung Jamu Sukoharjo.png, yang mencantumkan sumber Pemerintah Kabupaten Sukoharjo.
Foto produk lainnya menggunakan tautan dokumentasi dari media/situs terkait. Untuk publikasi resmi, periksa izin penggunaan foto dan cantumkan atribusi sesuai ketentuan sumber.

CATATAN ISI:
Katalog adalah media informasi awal, bukan toko resmi. Verifikasi kembali detail produk, lokasi, dan sumber informasi sebelum dipublikasikan.
