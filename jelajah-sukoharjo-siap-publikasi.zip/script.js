const products = [
  {
    id: 1,
    name: "Gamelan Desa Wirun",
    category: "Kerajinan",
    location: "Desa Wirun, Kecamatan Mojolaban",
    image: "https://indonesiasenang.com/content/images/2022/11/Desa-Wirun-Sukoharjo-Sentra-Pengrajin-Gamelan-5.jpg",
    summary: "Kerajinan alat musik tradisional yang dibuat melalui proses peleburan, pencetakan, penempaan, dan penyelarasan nada.",
    description: "Desa Wirun di Kecamatan Mojolaban dikenal sebagai sentra kerajinan gamelan. Proses pembuatan gamelan dimulai dari pengolahan bahan logam, terutama tembaga dan timah, untuk menghasilkan lempengan. Lempengan kemudian dipanaskan dan ditempa berulang kali hingga membentuk instrumen. Setelah bentuknya sesuai, pengrajin melakukan penyelarasan nada dengan mengandalkan pengalaman dan kepekaan pendengaran.",
    potential: "Gamelan Wirun memiliki nilai budaya sekaligus nilai ekonomi. Kegiatan produksi menjadi sumber penghidupan bagi pengrajin dan dapat dikembangkan sebagai wisata edukasi budaya, karena pengunjung dapat mengenal proses pembuatan alat musik tradisional secara langsung.",
    source: "Dinas Kebudayaan, Pariwisata, Pemuda dan Olahraga Provinsi Jawa Tengah; PIDEKSO Kabupaten Sukoharjo.",
    map: "Desa Wirun Mojolaban Sukoharjo"
  },
  {
    id: 2,
    name: "Mebel Rotan Trangsan",
    category: "Kerajinan",
    location: "Desa Trangsan, Kecamatan Gatak",
    image: "https://static.promediateknologi.id/crop/0x0%3A0x0/1200x600/webp/photo/p1/40/2025/08/29/03TRANGSAN-2869224057.jpg",
    summary: "Produk furnitur dan kerajinan berbahan rotan yang dikerjakan oleh pengrajin lokal Desa Trangsan.",
    description: "Desa Trangsan di Kecamatan Gatak telah dikenal sebagai kawasan industri pengolahan rotan. Pengrajin mengolah rotan menjadi berbagai produk, seperti kursi, meja, keranjang, dan perlengkapan rumah tangga. Proses pengerjaan membutuhkan keterampilan dalam memilih bahan, membentuk rangka, menganyam, menyambung, serta melakukan tahap akhir atau finishing agar produk kuat dan menarik.",
    potential: "Mebel rotan Trangsan memiliki potensi ekonomi karena produknya dipasarkan ke berbagai wilayah dan memiliki peluang pasar ekspor. Sentra ini juga berpotensi dikembangkan sebagai tujuan wisata industri kreatif untuk mengenalkan keterampilan pengrajin kepada pengunjung.",
    source: "Pariwisata Provinsi Jawa Tengah, artikel “Rotan, Karya Istimewa Desa Wisata Trangsan” (9 Maret 2021).",
    map: "Desa Trangsan Gatak Sukoharjo"
  },
  {
    id: 3,
    name: "Jamu Tradisional Nguter",
    category: "Kuliner",
    location: "Pasar Jamu Nguter, Kecamatan Nguter",
    image: "https://images.squarespace-cdn.com/content/v1/5e1bca246eeb973ee1c0ea94/1683101815227-TEQWRHPY1BGZYJIOL8NQ/Nyimas_Laula_FINAL_VOGUE_9291.JPG",
    summary: "Tradisi pengolahan dan perdagangan jamu yang menjadi bagian dari identitas Sukoharjo sebagai Kota Jamu.",
    description: "Kecamatan Nguter dikenal dengan tradisi perdagangan dan produksi jamu. Pasar Jamu Nguter menjadi tempat masyarakat menemukan berbagai bahan baku dan produk jamu tradisional. Pengetahuan tentang tanaman herbal, racikan, dan cara penyajian jamu diwariskan antargenerasi. Tradisi ini tidak hanya berkaitan dengan kebiasaan masyarakat, tetapi juga menjadi bagian dari aktivitas ekonomi para pedagang dan pelaku usaha jamu.",
    potential: "Potensi jamu Nguter dapat dikembangkan melalui pengenalan budaya jamu, wisata edukasi, inovasi kemasan, dan promosi digital bagi pelaku usaha. Desa Nguter juga telah ditetapkan sebagai Kampung Budaya Jamu melalui Keputusan Bupati Sukoharjo Nomor 400.9.12/327 Tahun 2025.",
    source: "Dinas Komunikasi dan Informatika Kabupaten Sukoharjo (27 Mei 2025); JDIH Kabupaten Sukoharjo, Keputusan Bupati Nomor 400.9.12/327 Tahun 2025.",
    map: "Pasar Jamu Nguter Sukoharjo"
  },
  {
    id: 4,
    name: "Batik Lokal Sukoharjo",
    category: "Tekstil",
    location: "Puron, Kecamatan Bulu dan sentra batik lokal lainnya",
    image: "https://3.bp.blogspot.com/-AOjkVjbEDKo/W-VttwiFIDI/AAAAAAAABCQ/x569lT4SLhkzOQDxczo9XH04ZPHK7a34gCLcBGAs/s1600/Batik%2BBiru%2BPuron%2BBulu%2BSukoharjo.jpg",
    summary: "Kain batik bermotif khas yang memperlihatkan kreativitas dan keterampilan perajin tekstil lokal.",
    description: "Kerajinan batik di Sukoharjo menjadi salah satu bentuk kreativitas masyarakat dalam mengolah kain bermotif. Salah satu dokumentasi batik lokal berasal dari Puron, Kecamatan Bulu, yang menampilkan kain batik berwarna biru dengan motif dekoratif. Proses membatik membutuhkan ketelitian dalam merancang pola, menerapkan malam atau lilin batik, memberi warna, dan menyelesaikan kain agar motif terlihat jelas.",
    potential: "Batik lokal dapat mendukung ekonomi kreatif melalui pengembangan motif, produk fesyen, suvenir, serta promosi digital. Informasi motif dan asal perajin perlu dilengkapi melalui konfirmasi langsung kepada pelaku usaha agar setiap produk yang ditampilkan memiliki identitas yang akurat.",
    source: "Dokumentasi batik Puron, Bulu, Sukoharjo. Informasi perajin dan motif perlu diverifikasi sebelum publikasi.",
    map: "Puron Bulu Sukoharjo"
  },
  {
    id: 5,
    name: "Tenun Sarung Goyor",
    category: "Tekstil",
    location: "Desa Pojok, Kecamatan Tawangsari",
    image: "https://images.bisnis.com/photos/2023/04/05/189618/antarafoto-permintaan-sarung-tenun-goyor-meningkat-040423-yud-3.jpg",
    summary: "Kain sarung tenun yang dibuat menggunakan keterampilan menenun dan alat tenun tradisional.",
    description: "Sarung goyor merupakan produk tekstil yang dikenal dari wilayah Sukoharjo. Pembuatan kain dilakukan melalui proses menenun dengan menyusun benang lungsi dan pakan hingga membentuk lembaran kain bermotif. Pekerjaan ini memerlukan ketelitian dan keterampilan agar susunan benang, motif, dan hasil kain tetap rapi. Proses produksi tenun juga memperlihatkan keterampilan yang diwariskan dan dipertahankan oleh para perajin.",
    potential: "Sarung goyor berpotensi menjadi produk unggulan tekstil dan suvenir daerah. Pengenalan proses tenun, variasi motif, serta promosi melalui katalog digital dapat membantu masyarakat mengenal produk dan sentra pembuatannya.",
    source: "ANTARA Foto / Bisnis.com, dokumentasi proses produksi sarung tenun goyor (5 April 2023).",
    map: "Desa Pojok Tawangsari Sukoharjo"
  }
];

const grid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");
const filterList = document.getElementById("filterList");
const emptyState = document.getElementById("emptyState");
let activeCategory = "Semua";

function renderProducts() {
  const keyword = searchInput.value.trim().toLowerCase();
  const filtered = products.filter(product => {
    const matchesCategory = activeCategory === "Semua" || product.category === activeCategory;
    const searchable = `${product.name} ${product.category} ${product.location} ${product.summary}`.toLowerCase();
    return matchesCategory && searchable.includes(keyword);
  });

  grid.innerHTML = filtered.map(product => `
    <article class="product-card">
      <div class="product-image-wrap">
        <img class="product-image" src="${product.image}" alt="${product.name}" loading="lazy"
          onerror="this.onerror=null;this.src='https://placehold.co/900x600/f3e8dc/173653?text=Foto+${encodeURIComponent(product.name)}'">
      </div>
      <div class="product-body">
        <span class="product-category">${product.category}</span>
        <h3>${product.name}</h3>
        <p class="product-location">⌖ ${product.location}</p>
        <p class="product-summary">${product.summary}</p>
        <button class="detail-button" data-id="${product.id}">Lihat informasi <span>→</span></button>
      </div>
    </article>
  `).join("");

  emptyState.hidden = filtered.length !== 0;
}

function openDetail(id) {
  const product = products.find(item => item.id === Number(id));
  if (!product) return;
  document.getElementById("modalImage").src = product.image;
  document.getElementById("modalImage").alt = product.name;
  document.getElementById("modalCategory").textContent = product.category;
  document.getElementById("modalTitle").textContent = product.name;
  document.getElementById("modalLocation").textContent = "⌖ " + product.location;
  document.getElementById("modalDescription").textContent = product.description;
  document.getElementById("modalPotential").textContent = product.potential;
  document.getElementById("modalSource").textContent = product.source;
  document.getElementById("modalMap").href = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(product.map);
  const modal = document.getElementById("detailModal");
  modal.classList.add("show");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closeDetail() {
  const modal = document.getElementById("detailModal");
  modal.classList.remove("show");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

grid.addEventListener("click", event => {
  const button = event.target.closest(".detail-button");
  if (button) openDetail(button.dataset.id);
});

searchInput.addEventListener("input", renderProducts);

filterList.addEventListener("click", event => {
  const button = event.target.closest(".filter-chip");
  if (!button) return;
  activeCategory = button.dataset.category;
  document.querySelectorAll(".filter-chip").forEach(chip => chip.classList.toggle("active", chip === button));
  renderProducts();
});

document.getElementById("modalClose").addEventListener("click", closeDetail);
document.getElementById("detailModal").addEventListener("click", event => {
  if (event.target.id === "detailModal") closeDetail();
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeDetail();
});

document.getElementById("menuToggle").addEventListener("click", () => {
  document.getElementById("mainNav").classList.toggle("open");
});
document.querySelectorAll(".main-nav a").forEach(link => {
  link.addEventListener("click", () => document.getElementById("mainNav").classList.remove("open"));
});

renderProducts();
